#include <iomanip>
#include "environment.h"
#include "random_num_gen.h"
#include "evaluator.h"
#include "agent.h"

using namespace std;

double doOneRun(Environment *env, int current_run);


int main(int argc, char *argv[]){

	double total_trufas=0, partial_trufas;
	ifstream fin;
	for (int current_run=1; current_run<11; current_run++){
	  fin.open(argv[1]);
          Environment* env=new Environment(fin);
          partial_trufas=doOneRun( env,current_run);
          cout << "Total Trufas Ejecucion " << current_run <<": " << partial_trufas << endl;
          total_trufas+=partial_trufas;
          fin.close();
	}
	cout << setprecision(3) << fixed << "Average Total Trufas: " << total_trufas/10.0 << endl;


  return 0;
}


double doOneRun(Environment *env, int current_run){
    int current_time=0;
    int dirty_degree=0;
    int consumed_energy=0;
    int life_time = 2000;
    double total_dirty_degree=0;
    double total_consumed_energy=0;
    RandomNumberGenerator *rng=new RandomNumberGenerator(env->RandomSeed()+current_run);
    Evaluator *evaluator=new Evaluator();
    Agent *agent=new Agent();
    Agent::ActionType action;
    char opcion='1';

    while (current_time<life_time){
        if (opcion!='0'){
            cout << "OPCIONES: (0) Ejecutar hasta el final   (1) Paso a paso \n";
            cin >> opcion;
        }

		env->Change(*rng);
		if (opcion=='1' or current_time==life_time-2)
            env->Show(0,0);

		agent->Perceive(*env);

		action = agent->Think();
		env->AcceptAction(action);
		evaluator->Eval(action,*env);

		++current_time;
	}
    return env->TrufaCollected();
}
